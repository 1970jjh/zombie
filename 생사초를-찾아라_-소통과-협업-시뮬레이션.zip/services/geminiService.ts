
/** 
 * 현재 버전에서는 관리자가 수동으로 성공/실패를 판정하므로 
 * Gemini를 통한 실시간 피드백 로직은 사용되지 않습니다.
 * 추후 자동 판정 기능 도입 시 다시 활성화할 수 있습니다.
 */
export async function getCollaborationHint(phase: string, teamInfo: string) {
  return "AI 전략 분석 기능은 현재 관리자 통제 모드로 인해 비활성화되었습니다.";
}

export async function checkAnswer(day: string, ampm: string, time: string) {
  // 클라이언트 측 검증 로직 (필요 시 활용)
  const isCorrect = day === '일요일' && ampm === '오전' && time === '09:30';
  return { success: isCorrect };
}
